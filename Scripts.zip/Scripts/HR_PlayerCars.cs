using UnityEngine;
using System.Collections;

[System.Serializable]
public class HR_PlayerCars : ScriptableObject {

	public static HR_PlayerCars instance;
	public static HR_PlayerCars Instance
	{
		get
		{
			if(instance == null)
				instance = Resources.Load("HR_Assets/HR_PlayerCars") as HR_PlayerCars;
			return instance;
		}
		
}

